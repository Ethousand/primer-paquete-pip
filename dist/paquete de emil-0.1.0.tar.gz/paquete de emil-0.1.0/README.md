# primer-paquete-pip
repositorio creado unicamente para practica de creaci[on de paquetes en python
